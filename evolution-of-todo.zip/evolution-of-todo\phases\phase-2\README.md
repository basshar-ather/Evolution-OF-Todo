Phase II - Evolution of Todo
=============================

This folder will contain Phase II extended backend and tests (authentication, user model, priority, due_date, filtering, sorting).
