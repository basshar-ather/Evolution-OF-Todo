Evolution of Todo
=================

This repository contains a five-phase Spec-Driven Development project called "Evolution of Todo". 

Phase I is implemented with FastAPI + SQLModel + SQLite. Subsequent phases are scaffolded.

See `phases/phase-1/backend/README.md` for Phase I run and test instructions.
