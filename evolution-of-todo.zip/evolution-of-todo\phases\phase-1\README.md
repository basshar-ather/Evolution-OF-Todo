Phase I – Core Todo Backend

Overview
--------
This phase implements a Todo backend using FastAPI, SQLModel and SQLite.

Phase II is implemented inside the same backend as an extension: authentication, User model, priority and due_date on Todo, filtering and sorting.

See `backend/README.md` for run and test instructions.
